package com.mirrordust.telecomlocate.interf;

/**
 * Created by LiaoShanhe on 2017/07/27/027.
 */

public interface BasePresenter {

    void subscribe();

    void unsubscribe();

}
