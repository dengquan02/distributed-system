package com.mirrordust.telecomlocate.interf;

/**
 * Created by LiaoShanhe on 2017/07/26/026.
 */

public interface OnSamplesUpdateListener {
    void onSamplesUpdate();
}
