package com.mirrordust.telecomlocate.interf;

/**
 * Created by LiaoShanhe on 2017/07/30/030.
 */

public interface OnAddOrUpdateSampleListener {
    void onAddOrUpdateSample();
}
